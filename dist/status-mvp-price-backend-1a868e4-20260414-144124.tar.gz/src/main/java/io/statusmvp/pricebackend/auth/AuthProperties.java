package io.statusmvp.pricebackend.auth;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Component
@ConfigurationProperties(prefix = "app.auth")
public class AuthProperties {
  private boolean enabled = true;
  private long oneTimeCodeTtlSeconds = 60;
  private long oauthStateTtlSeconds = 600;
  private long web3authJwtTtlSeconds = 300;
  private long accessTokenTtlSeconds = 900;
  private long refreshTokenTtlSeconds = 2_592_000;
  private long siweNonceTtlSeconds = 600;
  private String siweStatement = "VeilWallet wants you to sign in.";
  private boolean socialEnabled = false;
  private boolean xEnabled = true;
  private boolean tgEnabled = true;
  private boolean appleEnabled = true;
  private boolean syncEnabled = true;
  private boolean bindEnabled = true;
  private boolean metricsEnabled = true;
  private String appRedirectAllowlist = "";
  private String publicBaseUrl = "";

  private Web3Auth web3auth = new Web3Auth();
  private AppJwt appJwt = new AppJwt();
  private X x = new X();
  private Tg tg = new Tg();
  private Apple apple = new Apple();
  private Integrity integrity = new Integrity();
  private Risk risk = new Risk();

  public boolean isEnabled() {
    return enabled;
  }

  public void setEnabled(boolean enabled) {
    this.enabled = enabled;
  }

  public long getOneTimeCodeTtlSeconds() {
    return oneTimeCodeTtlSeconds;
  }

  public void setOneTimeCodeTtlSeconds(long oneTimeCodeTtlSeconds) {
    this.oneTimeCodeTtlSeconds = oneTimeCodeTtlSeconds;
  }

  public long getOauthStateTtlSeconds() {
    return oauthStateTtlSeconds;
  }

  public void setOauthStateTtlSeconds(long oauthStateTtlSeconds) {
    this.oauthStateTtlSeconds = oauthStateTtlSeconds;
  }

  public long getWeb3authJwtTtlSeconds() {
    return web3authJwtTtlSeconds;
  }

  public void setWeb3authJwtTtlSeconds(long web3authJwtTtlSeconds) {
    this.web3authJwtTtlSeconds = web3authJwtTtlSeconds;
  }

  public long getAccessTokenTtlSeconds() {
    return accessTokenTtlSeconds;
  }

  public void setAccessTokenTtlSeconds(long accessTokenTtlSeconds) {
    this.accessTokenTtlSeconds = accessTokenTtlSeconds;
  }

  public long getRefreshTokenTtlSeconds() {
    return refreshTokenTtlSeconds;
  }

  public void setRefreshTokenTtlSeconds(long refreshTokenTtlSeconds) {
    this.refreshTokenTtlSeconds = refreshTokenTtlSeconds;
  }

  public long getSiweNonceTtlSeconds() {
    return siweNonceTtlSeconds;
  }

  public void setSiweNonceTtlSeconds(long siweNonceTtlSeconds) {
    this.siweNonceTtlSeconds = siweNonceTtlSeconds;
  }

  public String getSiweStatement() {
    return siweStatement;
  }

  public void setSiweStatement(String siweStatement) {
    this.siweStatement = siweStatement;
  }

  public boolean isSocialEnabled() {
    return socialEnabled;
  }

  public void setSocialEnabled(boolean socialEnabled) {
    this.socialEnabled = socialEnabled;
  }

  public boolean isXEnabled() {
    return xEnabled;
  }

  public void setXEnabled(boolean xEnabled) {
    this.xEnabled = xEnabled;
  }

  public boolean isTgEnabled() {
    return tgEnabled;
  }

  public void setTgEnabled(boolean tgEnabled) {
    this.tgEnabled = tgEnabled;
  }

  public boolean isAppleEnabled() {
    return appleEnabled;
  }

  public void setAppleEnabled(boolean appleEnabled) {
    this.appleEnabled = appleEnabled;
  }

  public boolean isSyncEnabled() {
    return syncEnabled;
  }

  public void setSyncEnabled(boolean syncEnabled) {
    this.syncEnabled = syncEnabled;
  }

  public boolean isBindEnabled() {
    return bindEnabled;
  }

  public void setBindEnabled(boolean bindEnabled) {
    this.bindEnabled = bindEnabled;
  }

  public boolean isMetricsEnabled() {
    return metricsEnabled;
  }

  public void setMetricsEnabled(boolean metricsEnabled) {
    this.metricsEnabled = metricsEnabled;
  }

  public String getAppRedirectAllowlist() {
    return appRedirectAllowlist;
  }

  public void setAppRedirectAllowlist(String appRedirectAllowlist) {
    this.appRedirectAllowlist = appRedirectAllowlist;
  }

  public String getPublicBaseUrl() {
    return publicBaseUrl;
  }

  public void setPublicBaseUrl(String publicBaseUrl) {
    this.publicBaseUrl = publicBaseUrl;
  }

  public Web3Auth getWeb3auth() {
    return web3auth;
  }

  public void setWeb3auth(Web3Auth web3auth) {
    this.web3auth = web3auth;
  }

  public AppJwt getAppJwt() {
    return appJwt;
  }

  public void setAppJwt(AppJwt appJwt) {
    this.appJwt = appJwt;
  }

  public X getX() {
    return x;
  }

  public void setX(X x) {
    this.x = x;
  }

  public Tg getTg() {
    return tg;
  }

  public void setTg(Tg tg) {
    this.tg = tg;
  }

  public Apple getApple() {
    return apple;
  }

  public void setApple(Apple apple) {
    this.apple = apple;
  }

  public Integrity getIntegrity() {
    return integrity;
  }

  public void setIntegrity(Integrity integrity) {
    this.integrity = integrity;
  }

  public Risk getRisk() {
    return risk;
  }

  public void setRisk(Risk risk) {
    this.risk = risk;
  }

  public List<String> appRedirectAllowPrefixes() {
    return splitCsv(appRedirectAllowlist);
  }

  public static List<String> splitCsv(String csv) {
    if (csv == null || csv.isBlank()) return List.of();
    return Arrays.stream(csv.split(","))
        .map(String::trim)
        .filter(v -> !v.isEmpty())
        .collect(Collectors.toList());
  }

  public static class Web3Auth {
    private String clientId = "";
    private String clientSecret = "";
    private String issuer = "https://auth.status-mvp.local";
    private String audience = "status-mvp";
    private String keyId = "status-mvp-auth-v1";
    private String privateKeyPem = "";

    public String getClientId() {
      return clientId;
    }

    public void setClientId(String clientId) {
      this.clientId = clientId;
    }

    public String getClientSecret() {
      return clientSecret;
    }

    public void setClientSecret(String clientSecret) {
      this.clientSecret = clientSecret;
    }

    public String getIssuer() {
      return issuer;
    }

    public void setIssuer(String issuer) {
      this.issuer = issuer;
    }

    public String getAudience() {
      return audience;
    }

    public void setAudience(String audience) {
      this.audience = audience;
    }

    public String getKeyId() {
      return keyId;
    }

    public void setKeyId(String keyId) {
      this.keyId = keyId;
    }

    public String getPrivateKeyPem() {
      return privateKeyPem;
    }

    public void setPrivateKeyPem(String privateKeyPem) {
      this.privateKeyPem = privateKeyPem;
    }
  }

  public static class AppJwt {
    private String issuer = "status-mvp-price-backend";
    private String audience = "status-mvp-app";
    private String secret = "";

    public String getIssuer() {
      return issuer;
    }

    public void setIssuer(String issuer) {
      this.issuer = issuer;
    }

    public String getAudience() {
      return audience;
    }

    public void setAudience(String audience) {
      this.audience = audience;
    }

    public String getSecret() {
      return secret;
    }

    public void setSecret(String secret) {
      this.secret = secret;
    }
  }

  public static class X {
    private String clientId = "";
    private String clientSecret = "";
    private String redirectUri = "";
    /**
     * Optional secret for stateless OAuth state tokens.
     *
     * If set (recommended in multi-node deployments), the backend will:
     * - issue a signed state token (no Redis dependency for state)
     * - deterministically derive the PKCE code_verifier from the state payload
     *
     * Keep this value the same across all nodes.
     */
    private String stateSecret = "";
    private String scopes = "tweet.read users.read offline.access";
    private String authorizeEndpoint = "https://twitter.com/i/oauth2/authorize";
    private String tokenEndpoint = "https://api.twitter.com/2/oauth2/token";
    private String userinfoEndpoint = "https://api.twitter.com/2/users/me";

    public String getClientId() {
      return clientId;
    }

    public void setClientId(String clientId) {
      this.clientId = clientId;
    }

    public String getClientSecret() {
      return clientSecret;
    }

    public void setClientSecret(String clientSecret) {
      this.clientSecret = clientSecret;
    }

    public String getRedirectUri() {
      return redirectUri;
    }

    public void setRedirectUri(String redirectUri) {
      this.redirectUri = redirectUri;
    }

    public String getStateSecret() {
      return stateSecret;
    }

    public void setStateSecret(String stateSecret) {
      this.stateSecret = stateSecret;
    }

    public String getScopes() {
      return scopes;
    }

    public void setScopes(String scopes) {
      this.scopes = scopes;
    }

    public String getAuthorizeEndpoint() {
      return authorizeEndpoint;
    }

    public void setAuthorizeEndpoint(String authorizeEndpoint) {
      this.authorizeEndpoint = authorizeEndpoint;
    }

    public String getTokenEndpoint() {
      return tokenEndpoint;
    }

    public void setTokenEndpoint(String tokenEndpoint) {
      this.tokenEndpoint = tokenEndpoint;
    }

    public String getUserinfoEndpoint() {
      return userinfoEndpoint;
    }

    public void setUserinfoEndpoint(String userinfoEndpoint) {
      this.userinfoEndpoint = userinfoEndpoint;
    }

    public List<String> scopeList() {
      return AuthProperties.splitCsv(scopes.replace(" ", ","));
    }

  }

  public static class Tg {
    private String clientId = "";
    private String clientSecret = "";
    private String redirectUri = "";
    private String stateSecret = "";
    private String scopes = "openid";
    private String issuer = "https://oauth.telegram.org";
    private String authorizeEndpoint = "https://oauth.telegram.org/auth";
    private String tokenEndpoint = "https://oauth.telegram.org/token";
    private String jwksUri = "https://oauth.telegram.org/.well-known/jwks.json";
    private String botToken = "";
    private String botUsername = "";
    private long authMaxAgeSeconds = 600;
    private boolean legacyWidgetEnabled = false;

    public String getClientId() {
      return clientId;
    }

    public void setClientId(String clientId) {
      this.clientId = clientId;
    }

    public String getClientSecret() {
      return clientSecret;
    }

    public void setClientSecret(String clientSecret) {
      this.clientSecret = clientSecret;
    }

    public String getRedirectUri() {
      return redirectUri;
    }

    public void setRedirectUri(String redirectUri) {
      this.redirectUri = redirectUri;
    }

    public String getStateSecret() {
      return stateSecret;
    }

    public void setStateSecret(String stateSecret) {
      this.stateSecret = stateSecret;
    }

    public String getScopes() {
      return scopes;
    }

    public void setScopes(String scopes) {
      this.scopes = scopes;
    }

    public String getIssuer() {
      return issuer;
    }

    public void setIssuer(String issuer) {
      this.issuer = issuer;
    }

    public String getAuthorizeEndpoint() {
      return authorizeEndpoint;
    }

    public void setAuthorizeEndpoint(String authorizeEndpoint) {
      this.authorizeEndpoint = authorizeEndpoint;
    }

    public String getTokenEndpoint() {
      return tokenEndpoint;
    }

    public void setTokenEndpoint(String tokenEndpoint) {
      this.tokenEndpoint = tokenEndpoint;
    }

    public String getJwksUri() {
      return jwksUri;
    }

    public void setJwksUri(String jwksUri) {
      this.jwksUri = jwksUri;
    }

    public String getBotToken() {
      return botToken;
    }

    public void setBotToken(String botToken) {
      this.botToken = botToken;
    }

    public String getBotUsername() {
      return botUsername;
    }

    public void setBotUsername(String botUsername) {
      this.botUsername = botUsername;
    }

    public long getAuthMaxAgeSeconds() {
      return authMaxAgeSeconds;
    }

    public void setAuthMaxAgeSeconds(long authMaxAgeSeconds) {
      this.authMaxAgeSeconds = authMaxAgeSeconds;
    }

    public boolean isLegacyWidgetEnabled() {
      return legacyWidgetEnabled;
    }

    public void setLegacyWidgetEnabled(boolean legacyWidgetEnabled) {
      this.legacyWidgetEnabled = legacyWidgetEnabled;
    }

    public List<String> scopeList() {
      return AuthProperties.splitCsv(scopes.replace(" ", ","));
    }

    public String resolvedClientId() {
      if (clientId != null && !clientId.isBlank()) {
        return clientId.trim();
      }
      if (botToken == null || botToken.isBlank()) {
        return "";
      }
      int colon = botToken.indexOf(':');
      if (colon <= 0) {
        return "";
      }
      String prefix = botToken.substring(0, colon).trim();
      if (!prefix.matches("^\\d+$")) {
        return "";
      }
      return prefix;
    }
  }

  public static class Apple {
    private String audiences = "com.veilwallet.app";
    private String issuer = "https://appleid.apple.com";
    private String jwksUri = "https://appleid.apple.com/auth/keys";

    public String getAudiences() {
      return audiences;
    }

    public void setAudiences(String audiences) {
      this.audiences = audiences;
    }

    public String getIssuer() {
      return issuer;
    }

    public void setIssuer(String issuer) {
      this.issuer = issuer;
    }

    public String getJwksUri() {
      return jwksUri;
    }

    public void setJwksUri(String jwksUri) {
      this.jwksUri = jwksUri;
    }

    public List<String> audienceList() {
      return AuthProperties.splitCsv(audiences.replace(" ", ","));
    }
  }

  public static class Integrity {
    private boolean iosDeviceProofEnabled = true;
    private boolean androidDeviceProofEnabled = true;
    private boolean androidPlayIntegrityEnabled = true;
    private String androidProtectedAuthAllowedChannels = "play,direct";
    private long deviceProofChallengeTtlSeconds = 60;
    private long androidPlayIntegrityFreshnessSeconds = 180;
    private String androidPlayIntegrityPackageName = "com.statusmvp";
    private String androidPlayIntegrityServiceAccountEmail = "";
    private String androidPlayIntegrityServiceAccountPrivateKeyPem = "";
    private boolean iosAppAttestEnabled = true;
    private long appAttestChallengeTtlSeconds = 60;
    private long appAttestAssertionChallengeTtlSeconds = 60;
    private String iosAllowedApplicationIdentifiers = "4592CM9497.com.veilwallet.app";

    public boolean isIosDeviceProofEnabled() {
      return iosDeviceProofEnabled;
    }

    public void setIosDeviceProofEnabled(boolean iosDeviceProofEnabled) {
      this.iosDeviceProofEnabled = iosDeviceProofEnabled;
    }

    public boolean isAndroidDeviceProofEnabled() {
      return androidDeviceProofEnabled;
    }

    public void setAndroidDeviceProofEnabled(boolean androidDeviceProofEnabled) {
      this.androidDeviceProofEnabled = androidDeviceProofEnabled;
    }

    public boolean isAndroidPlayIntegrityEnabled() {
      return androidPlayIntegrityEnabled;
    }

    public void setAndroidPlayIntegrityEnabled(boolean androidPlayIntegrityEnabled) {
      this.androidPlayIntegrityEnabled = androidPlayIntegrityEnabled;
    }

    public String getAndroidProtectedAuthAllowedChannels() {
      return androidProtectedAuthAllowedChannels;
    }

    public void setAndroidProtectedAuthAllowedChannels(String androidProtectedAuthAllowedChannels) {
      this.androidProtectedAuthAllowedChannels = androidProtectedAuthAllowedChannels;
    }

    public long getDeviceProofChallengeTtlSeconds() {
      return deviceProofChallengeTtlSeconds;
    }

    public void setDeviceProofChallengeTtlSeconds(long deviceProofChallengeTtlSeconds) {
      this.deviceProofChallengeTtlSeconds = deviceProofChallengeTtlSeconds;
    }

    public long getAndroidPlayIntegrityFreshnessSeconds() {
      return androidPlayIntegrityFreshnessSeconds;
    }

    public void setAndroidPlayIntegrityFreshnessSeconds(long androidPlayIntegrityFreshnessSeconds) {
      this.androidPlayIntegrityFreshnessSeconds = androidPlayIntegrityFreshnessSeconds;
    }

    public List<String> androidProtectedAuthAllowedChannelsList() {
      return AuthProperties.splitCsv(androidProtectedAuthAllowedChannels).stream()
          .map(value -> value.toLowerCase(java.util.Locale.ROOT))
          .collect(Collectors.toList());
    }

    public String getAndroidPlayIntegrityPackageName() {
      return androidPlayIntegrityPackageName;
    }

    public void setAndroidPlayIntegrityPackageName(String androidPlayIntegrityPackageName) {
      this.androidPlayIntegrityPackageName = androidPlayIntegrityPackageName;
    }

    public String getAndroidPlayIntegrityServiceAccountEmail() {
      return androidPlayIntegrityServiceAccountEmail;
    }

    public void setAndroidPlayIntegrityServiceAccountEmail(String androidPlayIntegrityServiceAccountEmail) {
      this.androidPlayIntegrityServiceAccountEmail = androidPlayIntegrityServiceAccountEmail;
    }

    public String getAndroidPlayIntegrityServiceAccountPrivateKeyPem() {
      return androidPlayIntegrityServiceAccountPrivateKeyPem;
    }

    public void setAndroidPlayIntegrityServiceAccountPrivateKeyPem(String androidPlayIntegrityServiceAccountPrivateKeyPem) {
      this.androidPlayIntegrityServiceAccountPrivateKeyPem = androidPlayIntegrityServiceAccountPrivateKeyPem;
    }

    public boolean isIosAppAttestEnabled() {
      return iosAppAttestEnabled;
    }

    public void setIosAppAttestEnabled(boolean iosAppAttestEnabled) {
      this.iosAppAttestEnabled = iosAppAttestEnabled;
    }

    public long getAppAttestChallengeTtlSeconds() {
      return appAttestChallengeTtlSeconds;
    }

    public void setAppAttestChallengeTtlSeconds(long appAttestChallengeTtlSeconds) {
      this.appAttestChallengeTtlSeconds = appAttestChallengeTtlSeconds;
    }

    public long getAppAttestAssertionChallengeTtlSeconds() {
      return appAttestAssertionChallengeTtlSeconds;
    }

    public void setAppAttestAssertionChallengeTtlSeconds(long appAttestAssertionChallengeTtlSeconds) {
      this.appAttestAssertionChallengeTtlSeconds = appAttestAssertionChallengeTtlSeconds;
    }

    public String getIosAllowedApplicationIdentifiers() {
      return iosAllowedApplicationIdentifiers;
    }

    public void setIosAllowedApplicationIdentifiers(String iosAllowedApplicationIdentifiers) {
      this.iosAllowedApplicationIdentifiers = iosAllowedApplicationIdentifiers;
    }

    public List<String> iosAllowedApplicationIdentifiersList() {
      return AuthProperties.splitCsv(iosAllowedApplicationIdentifiers);
    }
  }

  public static class Risk {
    private String blacklistIps = "";
    private String blacklistProviderSubs = "";
    private String trustedProxyIps = "127.0.0.1,::1";
    private int loginIpLimit = 20;
    private int loginDeviceLimit = 30;
    private int bindAccountLimit = 20;
    private int windowSeconds = 60;

    public String getBlacklistIps() {
      return blacklistIps;
    }

    public void setBlacklistIps(String blacklistIps) {
      this.blacklistIps = blacklistIps;
    }

    public String getBlacklistProviderSubs() {
      return blacklistProviderSubs;
    }

    public void setBlacklistProviderSubs(String blacklistProviderSubs) {
      this.blacklistProviderSubs = blacklistProviderSubs;
    }

    public String getTrustedProxyIps() {
      return trustedProxyIps;
    }

    public void setTrustedProxyIps(String trustedProxyIps) {
      this.trustedProxyIps = trustedProxyIps;
    }

    public int getLoginIpLimit() {
      return loginIpLimit;
    }

    public void setLoginIpLimit(int loginIpLimit) {
      this.loginIpLimit = loginIpLimit;
    }

    public int getLoginDeviceLimit() {
      return loginDeviceLimit;
    }

    public void setLoginDeviceLimit(int loginDeviceLimit) {
      this.loginDeviceLimit = loginDeviceLimit;
    }

    public int getBindAccountLimit() {
      return bindAccountLimit;
    }

    public void setBindAccountLimit(int bindAccountLimit) {
      this.bindAccountLimit = bindAccountLimit;
    }

    public int getWindowSeconds() {
      return windowSeconds;
    }

    public void setWindowSeconds(int windowSeconds) {
      this.windowSeconds = windowSeconds;
    }

    public List<String> blacklistIpList() {
      return AuthProperties.splitCsv(blacklistIps);
    }

    public List<String> blacklistProviderSubList() {
      return AuthProperties.splitCsv(blacklistProviderSubs);
    }

    public List<String> trustedProxyIpList() {
      return AuthProperties.splitCsv(trustedProxyIps);
    }
  }
}
